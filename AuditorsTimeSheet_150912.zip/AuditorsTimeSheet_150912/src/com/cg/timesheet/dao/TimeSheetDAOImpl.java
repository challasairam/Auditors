package com.cg.timesheet.dao;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.timesheet.client.TimeSheetBean;

@Repository
@Transactional
public class TimeSheetDAOImpl implements ITimeSheetDAO {

	@PersistenceContext
	EntityManager entityManager;

	/**************************************************************************************
	*Method Name               : insertDetails
	*Author Name               : Sairam Challa,150912
	*Description               : To insert values into Database table
	*Version                   : 1.0
	*Created Date              : 10-Jul-2018
	*Input Parameters          : TimeSheetBean object
	*Return Type               : TimeSheetBean object
	**************************************************************************************/

	@Override
	public TimeSheetBean insertDetails(TimeSheetBean bean) {
		try {
			String currentDate = bean.getDate();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date date = sdf.parse(currentDate);
			java.sql.Date sqlCurrentDate = new java.sql.Date(date.getTime());
			bean.setTimeSheetDate(sqlCurrentDate);
			entityManager.persist(bean);
			entityManager.flush();
		} catch (Exception e) {

		}
		return bean;
	}

	/**************************************************************************************
	*Method Name               : getDetails
	*Author Name               : Sairam Challa,150912
	*Description               : To retrieve values from database table
	*Version                   : 1.0
	*Created Date              : 10-Jul-2018
	*Input Parameters          : Employee Id of string datatype
	*Return Type               : ArrayList of TimeSheetBean objects
	**************************************************************************************/
	@Override
	public ArrayList<TimeSheetBean> getDetailsById(String empId) {
		Query query = entityManager.createNamedQuery("getDetails");
		query.setParameter("id", empId);
		@SuppressWarnings("unchecked")
		ArrayList<TimeSheetBean> list = (ArrayList<TimeSheetBean>) query
				.getResultList();
		return list;
	}
}
