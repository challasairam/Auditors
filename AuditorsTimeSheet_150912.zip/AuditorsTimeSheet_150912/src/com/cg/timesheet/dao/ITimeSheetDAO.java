package com.cg.timesheet.dao;

import java.util.ArrayList;

import com.cg.timesheet.client.TimeSheetBean;

public interface ITimeSheetDAO {
	public TimeSheetBean insertDetails(TimeSheetBean bean);

	public ArrayList<TimeSheetBean> getDetailsById(String empId);
}
