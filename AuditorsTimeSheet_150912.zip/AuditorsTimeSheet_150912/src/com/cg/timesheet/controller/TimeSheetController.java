package com.cg.timesheet.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.timesheet.client.TimeSheetBean;
import com.cg.timesheet.service.ITimeSheetService;

@Controller
public class TimeSheetController {

	@Autowired
	ITimeSheetService service;

	/*
	 * To display Home Page
	 */
	@RequestMapping("index")
	public ModelAndView getHomePage() {
		ModelAndView view = new ModelAndView("HomePage");
		return view;

	}

	/*
	 * To display TimeSheet entry page
	 */
	@RequestMapping("enterTimeSheet")
	public ModelAndView getEntryPage() {

		ModelAndView view = new ModelAndView("timeSheetEntry", "bean",
				new TimeSheetBean());
		ArrayList<String> activities = new ArrayList<>();
		activities.add("SELECT");
		activities.add("DATA_ENTRY");
		activities.add("ACCOUNTS_TALLY");
		activities.add("LEDGER_POSTINGS");
		activities.add("BALANCE_SHEET");
		activities.add("RETURNS_FILING");
		view.addObject("activities", activities);
		return view;

	}

	/*
	 * To store details in the database table
	 */
	@RequestMapping("saveDetails")
	public ModelAndView saveDetails(
			@ModelAttribute("bean") @Valid TimeSheetBean bean,
			BindingResult bindingResult) {
		ModelAndView view = new ModelAndView();

		if (bindingResult.hasErrors()) {
			view = new ModelAndView("timeSheetEntry");
			ArrayList<String> activities = new ArrayList<>();
			activities.add("DATA_ENTRY");
			activities.add("ACCOUNTS_TALLY");
			activities.add("LEDGER_POSTINGS");
			activities.add("BALANCE_SHEET");
			activities.add("RETURNS_FILING");
			view.addObject("activities", activities);
		} else {

			TimeSheetBean bean2 = service.insertDetails(bean);
			view.addObject("id", bean2.getTimeSheetId());
			view.setViewName("success");
		}
		return view;

	}

	/*
	 * To display Time Sheet List page
	 */
	@RequestMapping("listTimeSheets")
	public ModelAndView getTimeSheetList() {
		ModelAndView view = new ModelAndView("timeSheetList", "bean",
				new TimeSheetBean());
		return view;

	}
	/*
	 * To retrieve details based on employee Id
	 */
	@RequestMapping("getdetails")
	public ModelAndView getDetailsById(
			@ModelAttribute("bean") TimeSheetBean bean) {
		ModelAndView view = new ModelAndView();
		ArrayList<TimeSheetBean> list = service.getDetailsById(bean.getEmpId());
		if (!list.isEmpty()) {
			view = new ModelAndView("timeSheetList", "bean",
					new TimeSheetBean());
			view.addObject("list", list);
			ArrayList<String> list1 = new ArrayList<String>();
			list1.add("Once");
			view.addObject("list1", list1);
		} else {
			view = new ModelAndView("timeSheetList", "bean",
					new TimeSheetBean());
			view.addObject("message", "No time sheets recorded!");
		}
		return view;

	}
}
