package com.cg.timesheet.service;

import java.util.ArrayList;

import com.cg.timesheet.client.TimeSheetBean;

public interface ITimeSheetService {

	public TimeSheetBean insertDetails(TimeSheetBean bean);

	public ArrayList<TimeSheetBean> getDetailsById(String empId);

}
