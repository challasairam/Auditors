package com.cg.timesheet.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.timesheet.client.TimeSheetBean;
import com.cg.timesheet.dao.ITimeSheetDAO;

@Service
public class TimeSheetServiceImpl implements ITimeSheetService {

	@Autowired
	ITimeSheetDAO dao;

	@Override
	public TimeSheetBean insertDetails(TimeSheetBean bean) {

		return dao.insertDetails(bean);
	}

	@Override
	public ArrayList<TimeSheetBean> getDetailsById(String empId) {

		return dao.getDetailsById(empId);
	}
}
