package com.cg.timesheet.client;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "timesheet")
@NamedQuery(name = "getDetails", query = "select t from TimeSheetBean t where t.empId=:id")
public class TimeSheetBean {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "timesheet_id")
	private Integer timeSheetId;
	@Column(name = "emp_id")
	@NotEmpty(message = "Should not be null")
	@Pattern(regexp = "[A-Z]{3}[0-9]{5}", message = "Sample emp id : EMP00001")
	private String empId;
	@Transient
	private String date;
	@NotEmpty(message = "Should not be null")
	private String hour1;
	@NotEmpty(message = "Should not be null")
	private String hour2;
	@NotEmpty(message = "Should not be null")
	private String hour3;
	@NotEmpty(message = "Should not be null")
	private String hour4;
	@NotEmpty(message = "Should not be null")
	private String hour5;
	@NotEmpty(message = "Should not be null")
	private String hour6;
	@NotEmpty(message = "Should not be null")
	private String hour7;
	@NotEmpty(message = "Should not be null")
	private String hour8;

	@Column(name = "timesheet_date")
	private Date timeSheetDate;

	public Integer getTimeSheetId() {
		return timeSheetId;
	}

	public void setTimeSheetId(Integer timeSheetId) {
		this.timeSheetId = timeSheetId;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Date getTimeSheetDate() {
		return timeSheetDate;
	}

	public void setTimeSheetDate(Date timeSheetDate) {
		this.timeSheetDate = timeSheetDate;
	}

	public String getHour1() {
		return hour1;
	}

	public void setHour1(String hour1) {
		this.hour1 = hour1;
	}

	public String getHour2() {
		return hour2;
	}

	public void setHour2(String hour2) {
		this.hour2 = hour2;
	}

	public String getHour3() {
		return hour3;
	}

	public void setHour3(String hour3) {
		this.hour3 = hour3;
	}

	public String getHour4() {
		return hour4;
	}

	public void setHour4(String hour4) {
		this.hour4 = hour4;
	}

	public String getHour5() {
		return hour5;
	}

	public void setHour5(String hour5) {
		this.hour5 = hour5;
	}

	public String getHour6() {
		return hour6;
	}

	public void setHour6(String hour6) {
		this.hour6 = hour6;
	}

	public String getHour7() {
		return hour7;
	}

	public void setHour7(String hour7) {
		this.hour7 = hour7;
	}

	public String getHour8() {
		return hour8;
	}

	public void setHour8(String hour8) {
		this.hour8 = hour8;
	}

	public TimeSheetBean() {

	}

	@Override
	public String toString() {
		return "TimeSheetBean [timeSheetId=" + timeSheetId + ", empId=" + empId
				+ ", timeSheetDate=" + timeSheetDate + ", hour1=" + hour1
				+ ", hour2=" + hour2 + ", hour3=" + hour3 + ", hour4=" + hour4
				+ ", hour5=" + hour5 + ", hour6=" + hour6 + ", hour7=" + hour7
				+ "]";
	}

}
